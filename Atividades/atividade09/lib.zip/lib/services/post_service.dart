// lib/services/post_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/post.dart';

class PostService {
  // Base URL da API REST
  static const String _baseUrl = 'https://jsonplaceholder.typicode.com';

  /// Busca a lista de posts (GET /posts).
  Future<List<Post>> fetchPosts() async {
    final url = Uri.parse('$_baseUrl/posts');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      // Decodifica o JSON e transforma em lista de Post
      final List<dynamic> jsonList = jsonDecode(response.body) as List<dynamic>;
      return jsonList
          .map((jsonItem) => Post.fromJson(jsonItem as Map<String, dynamic>))
          .toList();
    } else {
      throw Exception('Erro ao buscar posts: ${response.statusCode}');
    }
  }

  /// Cria um novo post (POST /posts).
  Future<Post> createPost(Post post) async {
    final url = Uri.parse('$_baseUrl/posts');
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(post.toJson()),
    );

    if (response.statusCode == 201 || response.statusCode == 200) {
      final Map<String, dynamic> jsonMap =
          jsonDecode(response.body) as Map<String, dynamic>;
      return Post.fromJson(jsonMap);
    } else {
      throw Exception('Erro ao criar post: ${response.statusCode}');
    }
  }
}
