// lib/main.dart
import 'package:flutter/material.dart';
import 'models/post.dart';
import 'services/post_service.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter REST Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const PostListPage(),
    );
  }
}

class PostListPage extends StatefulWidget {
  const PostListPage({super.key});

  @override
  State<PostListPage> createState() => _PostListPageState();
}

class _PostListPageState extends State<PostListPage> {
  final PostService _service = PostService();
  late Future<List<Post>> _futurePosts;

  @override
  void initState() {
    super.initState();
    // Inicia a requisição REST assim que a tela é criada
    _futurePosts = _service.fetchPosts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Posts (REST API)'),
      ),
      body: FutureBuilder<List<Post>>(
        future: _futurePosts,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            // Estado de carregamento enquanto a requisição ainda não terminou
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            // Exibe mensagem de erro caso algo dê errado
            return Center(
              child: Text('Erro: ${snapshot.error}'),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            // Caso a resposta seja vazia
            return const Center(
              child: Text('Nenhum post encontrado'),
            );
          } else {
            // Dados carregados com sucesso: exibe a lista de posts
            final posts = snapshot.data!;
            return ListView.builder(
              itemCount: posts.length,
              itemBuilder: (context, index) {
                final post = posts[index];
                return ListTile(
                  title: Text(post.title),
                  subtitle: Text(post.body),
                );
              },
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        // Exemplo simples de uso do POST ao clicar no botão
        onPressed: () async {
          final newPost = Post(
            userId: 1,
            id: 0, // a API de teste ignora esse id
            title: 'Novo post',
            body: 'Conteúdo do novo post',
          );

          try {
            final created = await _service.createPost(newPost);
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                    'Post criado (id: ${created.id}, title: ${created.title})'),
              ),
            );
          } catch (e) {
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Erro ao criar post: $e'),
              ),
            );
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
